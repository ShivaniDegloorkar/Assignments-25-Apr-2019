package com.ibm.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.dao.Dao;

@WebServlet("/delete")
public class DeleteTraining extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");

		Cookie[] c = request.getCookies(); int flag = 0; Cookie mycookie = null;
		try
		{
			for(Cookie ck: c)
			{
				if(ck.getName().equals("Username"))
				{
					System.out.println("username found");
					flag = 1;
					mycookie = ck;
					break;
				}
			}
		}catch(NullPointerException e)
		{
			System.out.println("no cookies set");
		}
		
		
		if(flag == 1)
		{
			Dao dao = new Dao();
			int deleteid;
			String temp = request.getParameter("deleteid");
			deleteid = Integer.parseInt(temp);
			RequestDispatcher rd = request.getRequestDispatcher("admin.html");
			PrintWriter pw = response.getWriter();
			
			if(!dao.checkID(deleteid))
			{
				if(dao.deleteCourse(deleteid))
				{
					pw.println("Course deleted Successfully\n");
					rd.include(request, response);
				}
			}
			else
			{
				pw.println("Course could not be deleted. \n ID should not match with existing courses \n");
				rd.include(request, response);
			}
		}
		else
		{
			System.out.println("no cookies set");
			response.getWriter().println("Enter your credentials and then enter\n");
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.html");
			dispatcher.include(request, response);
		}
		
		
	}

}
