package com.ibm.takehome.ui;

import java.util.Scanner;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.exception.UserException;
import com.ibm.takehome.service.Service;

public class Main {
	static Service service;
	public static void main(String[] args) 
	{
		service = new Service();
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		boolean exit = true;
		while(exit)
		{
			
			try
			{
				System.out.println("1. Generate Bill by entering Product code and quantity "
								 + "\n2. Exit");
				choice = sc.nextInt();
				sc.nextLine();
				switch(choice)
				{
				case 1:
					System.out.println("Enter product code");
					String product_code = sc.nextLine();
					try
					{
						if(service.validateProductCode(product_code))
						{
							Product product = service.getProductDetails(product_code);
							System.out.println("Enter product quantity");
							int product_quantity = sc.nextInt();
							if(service.validateProductQuantity(product_quantity))
							{
								System.out.println("Product Name : "+ product.getProduct_name());
								System.out.println("Product Category : "+ product.getProduct_category());
								System.out.println("Product Price : "+ product.getProduct_price());
								System.out.println("Quantity : "+ product_quantity);
								System.out.println("Line Total (Rs) : "+ product.getProduct_price() * product_quantity);
							}
						}
					}
					catch(UserException ue)
					{
						System.out.println(ue);
					}
				break;
				case 2:
					exit = false;
					break;
					
				default:
					System.out.println("Enter correct input");
				}
				
			
			}catch(Exception e)
			{
				System.out.println("Enter input in appropriate format");
				sc.nextLine();
			}

		}
	}

}
