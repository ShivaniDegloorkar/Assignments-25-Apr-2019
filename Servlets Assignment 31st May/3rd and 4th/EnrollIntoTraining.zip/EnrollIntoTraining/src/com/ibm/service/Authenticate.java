package com.ibm.service;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/auth")
public class Authenticate extends HttpServlet {
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			response.setContentType("text/html");

			String name = request.getParameter("username");
			String pass = request.getParameter("password");
			if(name.equals("admin") && pass.equals("root"))
			{
				System.out.println("Setting cookie in authentication");
				
				Cookie thecookie = new Cookie("Username", name);
				thecookie.setMaxAge(3600);
				response.addCookie(thecookie);
				response.sendRedirect("admin.html");
			}
			else if(name.equals("user") && pass.equals("user"))
			{
				System.out.println("Setting cookie in authentication");
				
				Cookie thecookie = new Cookie("Username", name);
				thecookie.setMaxAge(3600);
				response.addCookie(thecookie);
				response.sendRedirect("showAllTraining");
			}
			else
			{
				response.getWriter().println("Enter correct credentials and then enter\n");
				RequestDispatcher dispatcher = request.getRequestDispatcher("index.html");
				dispatcher.include(request, response);
			}
		}
}
