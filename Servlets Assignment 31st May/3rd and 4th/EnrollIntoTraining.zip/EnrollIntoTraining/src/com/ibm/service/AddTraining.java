package com.ibm.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.dao.Dao;


@WebServlet("/add")
public class AddTraining extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");

		Cookie[] c = request.getCookies(); int flag = 0; Cookie mycookie = null;
		
		try
		{
			for(Cookie ck: c)
			{
				if(ck.getName().equals("Username"))
				{
					System.out.println("username found");
					flag = 1;
					mycookie = ck;
					break;
				}
			}
		}catch(NullPointerException e)
		{
			System.out.println("no cookies set");
		}
		
		if(flag == 1)
		{
			Dao dao = new Dao();
			int id,seats;
			String temp = request.getParameter("id");
			id = Integer.parseInt(temp);
			String course = request.getParameter("course");
			temp = request.getParameter("seats");
			seats = Integer.parseInt(temp);
			
			RequestDispatcher rd = request.getRequestDispatcher("admin.html");
			PrintWriter pw = response.getWriter();
			
			if(dao.checkID(id))
			{
				if(dao.addCourse(id, course, seats))
				{
					pw.println("Course Added Successfully \n");
					rd.include(request, response);
				}
			}
			else
			{
				pw.println("Course could not be added. \n ID should not match with existing courses \n");
				rd.include(request, response);
			}

		}
		else
		{
			System.out.println("no cookies set");
			response.getWriter().println("Enter your credentials and then enter\n");
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.html");
			dispatcher.include(request, response);
		}
		
	}

}
