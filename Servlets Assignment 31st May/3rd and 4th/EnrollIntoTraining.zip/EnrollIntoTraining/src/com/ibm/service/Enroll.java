package com.ibm.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.dao.Dao;


@WebServlet("/enroll")
public class Enroll extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		Cookie[] c = request.getCookies(); int flag = 0; Cookie mycookie = null;
		try
		{
			for(Cookie ck: c)
			{
				if(ck.getName().equals("Username"))
				{
					System.out.println("username found");
					flag = 1;
					mycookie = ck;
					break;
				}
			}
		}catch(NullPointerException e)
		{
			System.out.println("no cookies set");
		}
		
		
		if(flag == 1)
		{
			Dao dao = new Dao();
			PrintWriter pw = response.getWriter();
			String temp = request.getParameter("trainid");
			String course = request.getParameter("course");
			int id = Integer.parseInt(temp);
			System.out.println(id);
			int availableSeats = 0;
				availableSeats = dao.getAvailableSeats(id);
				RequestDispatcher rd = request.getRequestDispatcher("showAllTraining");
				if(availableSeats > 0)
				{
					System.out.println("seats are avail");
					if(dao.enroll(id))
					{
						System.out.println("Updated successfully");
						pw.println("Hi! You are successfully enrolled for "+course+" course");
						rd.include(request, response);
					}
				}
				else
				{
					System.out.println("Sorry no seats available to enroll");
					pw.println("Sorry no seats available to enroll");
					rd.include(request, response);
				}
			

		}
		else
		{
			System.out.println("no cookies set");
			response.getWriter().println("Enter your credentials and then enter\n");
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.html");
			dispatcher.include(request, response);
		}
		
			}


}
