package com.ibm.takehome.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.dao.Dao;

class AppTest {
	static Dao dao = null;
	@BeforeAll
	static void setUpBeforeClass() throws Exception 
	{
		dao = new Dao();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@ParameterizedTest
	@ValueSource(strings = {"1001","1002","1003","1004","1005"})
	void test(String codes) 
	{
		boolean check;
		Product p = dao.getProductDetails(codes);
		assertNotEquals(p, null);
	}
	

}
