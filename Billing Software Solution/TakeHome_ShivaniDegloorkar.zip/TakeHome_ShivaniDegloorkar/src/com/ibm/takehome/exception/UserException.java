package com.ibm.takehome.exception;

public class UserException extends Exception
{
	public UserException(String str)
	{
		super(str);
	}
}
