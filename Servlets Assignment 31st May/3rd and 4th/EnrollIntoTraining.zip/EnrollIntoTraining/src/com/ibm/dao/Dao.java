package com.ibm.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Dao 
{
	Connection dbCon;
	PreparedStatement statement;
	int numberOfCourses , availableseats;
	int []trainids=new int[3];
	int []trainseats=new int[3];
	String []traincourses=new String[3];
	public Dao()
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/trainingcourses", "root", "");
			System.out.println("Database Connected");
		}
		catch (ClassNotFoundException | SQLException e) 
		{
			System.out.println("Issues connecting to databse : "+e);
		} 
	}
	
	public boolean checkID(int id)
	{
		try 
		{
			statement = dbCon.prepareStatement("SELECT TrainingId FROM trainCourseInfo");
			ResultSet rs = statement.executeQuery();
			while(rs.next())
			{
				if(rs.getInt("TrainingId") == id)
					return false;
			}
		}
		catch (SQLException e) 
		{
			System.out.println("while checking id: "+e);
		}
		return true;

	}
	
	public boolean addCourse(int id, String CourseName, int seats)
	{
		try {
			statement = dbCon.prepareStatement("INSERT INTO traincourseinfo (TrainingId, TrainingName, AvailableSeats) VALUES (?, ?, ?)");
			statement.setInt(1, id);
			statement.setString(2, CourseName);
			statement.setInt(3, seats);
			if(statement.executeUpdate() > 0)
				return true;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		return false;
	}
	
	public boolean updateCourse(int updateid, int id, String CourseName, int seats)
	{
		String updatequery = "UPDATE traincourseinfo SET TrainingId=?,TrainingName=?,AvailableSeats=? WHERE TrainingId=?";
		try {
			statement = dbCon.prepareStatement(updatequery);
			statement.setInt(1, id);
			statement.setString(2, CourseName);
			statement.setInt(3, seats);
			statement.setInt(4, updateid);
			
			if(statement.executeUpdate() > 0)
			{
				return true;
			}
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}

	public boolean deleteCourse(int deleteid) 
	{
		String deletequery = "delete from traincourseinfo WHERE TrainingId=?";
		try {
			statement = dbCon.prepareStatement(deletequery);
			statement.setInt(1, deleteid);
			if(statement.executeUpdate() > 0)
			{
				return true;
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public int getNumberOfCourses()
	{
		try 
		{
			statement = dbCon.prepareStatement("SELECT TrainingId FROM trainCourseInfo");
			ResultSet rs = statement.executeQuery();
			while(rs.next())
			{
				numberOfCourses++;
			}
		}
		catch (SQLException e) 
		{
			System.out.println(e);
		}

		return numberOfCourses;
	}
	public void getTrainTable()
	{
		int i = 0;
		try 
		{
			statement = dbCon.prepareStatement("SELECT * FROM trainCourseInfo");
			ResultSet rs = statement.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getInt(1));
				trainseats[i] = rs.getInt(3);
				//System.out.println("-------2------");
				trainids[i] = rs.getInt(1);
				//System.out.println("-------3------");
				traincourses[i] = rs.getString(2);
				//System.out.println("-------4------");
				
				i++;
			}
		}
		catch (SQLException e) 
		{
			System.out.println("Id "+e);
		}
	}
	
	public int[] getTrainids() {
		
		return trainids;
	}

	public String[] getTrainCourses() {
		
		return traincourses;
	}

	public int[] getTrainSeats() {
		
		return trainseats;
	}
	
	public boolean enroll(int id)
	{
		try
		{
			statement = dbCon.prepareStatement("UPDATE traincourseinfo SET AvailableSeats = ? WHERE TrainingId = ?");
			statement.setInt(1, availableseats-1);
			statement.setInt(2, id);
			if(statement.executeUpdate() > 0)
			{
				return true;
			}
		}catch(SQLException e)
		{
			
		}
		return false;
	}
	
	public int getAvailableSeats(int id)
	{
		try 
		{
			statement = dbCon.prepareStatement("SELECT AvailableSeats FROM trainCourseInfo where TrainingId = ?");
			statement.setInt(1, id);
			ResultSet rs = statement.executeQuery();
			while(rs.next())
			{
				availableseats = rs.getInt("AvailableSeats");
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		
		return availableseats;
	}

	

	

}
