package com.ibm.takehome.service;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.dao.Dao;
import com.ibm.takehome.exception.UserException;

public class Service {
	
	Dao dao = new Dao();

	public boolean validateProductCode(String product_code) throws UserException
	{
		if (product_code == null) 
			throw new UserException("Sorry ! Product code cannot be empty");
		
		if(product_code.length() == 4)
		{
		    
		    for (int i = 0; i < product_code.length(); i++)
		    	if ((Character.isDigit(product_code.charAt(i)) == false)) 
					throw new UserException("Sorry ! Product code cannot contain anything other than digits");

		    
		   return true;
		}
		
		throw new UserException("Sorry ! Product code must contain only 4 digits");
	}

	public Product getProductDetails(String product_code) throws UserException
	{
		Product product = dao.getProductDetails(product_code);
		if(product == null)
			throw new UserException("Sorry ! The Product Code <<"+product_code+">> is not available");
		
		return dao.getProductDetails(product_code);
	}

	public boolean validateProductQuantity(int product_quantity) throws UserException 
	{
		if(product_quantity <= 0)
			throw new UserException("Sorry ! Product quantity cannot be zero or less");
		
		else
			return true;
	}

}
