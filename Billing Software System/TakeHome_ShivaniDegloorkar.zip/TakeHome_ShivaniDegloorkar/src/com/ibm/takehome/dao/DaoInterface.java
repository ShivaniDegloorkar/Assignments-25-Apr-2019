package com.ibm.takehome.dao;

import com.ibm.takehome.bean.Product;

public interface DaoInterface 
{
	public Product getProductDetails(String product_code);
}
