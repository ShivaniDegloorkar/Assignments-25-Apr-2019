package com.ibm.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.dao.Dao;


@WebServlet("/update")
public class UpdateTraining extends HttpServlet {
	
	boolean bid,bcourse,bseats;
	int updateid,id,seats;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");

		Cookie[] c = request.getCookies(); int flag = 0; Cookie mycookie = null;
		try
		{
			for(Cookie ck: c)
			{
				if(ck.getName().equals("Username"))
				{
					System.out.println("username found");
					flag = 1;
					mycookie = ck;
					break;
				}
			}
		}catch(NullPointerException e)
		{
			System.out.println("no cookies set");
		}
		
		
		if(flag == 1)
		{
			Dao dao = new Dao();
			
			String temp = request.getParameter("updateid");
			updateid = Integer.parseInt(temp);
			
			temp = request.getParameter("id");
			if(temp!=null)
			{
				id = Integer.parseInt(temp);
				bid = true;
			}
			
			String course = request.getParameter("course");
			if(course!=null)
			{
				bcourse = true;
			}
			
			temp = request.getParameter("seats");
			if(temp!=null)
			{
				seats = Integer.parseInt(temp);
				bseats = true;
			}
			
			RequestDispatcher rd = request.getRequestDispatcher("admin.html");
			PrintWriter pw = response.getWriter();
			
			if(!dao.checkID(updateid))
			{
				if(bcourse && bid && bseats)
				{
					if(dao.updateCourse(updateid, id, course, seats)) 
					{	
						pw.println("Course updated successfully.\n");
						rd.include(request, response);
					}
				}
				else
				{
					pw.println("Course could not be updated. \n Enter all the fields \n");
					rd.include(request, response);
				}
				
			}
			else
			{
				pw.println("Course could not be updated. \n ID didnot match with any course \n");
				rd.include(request, response);
			}

		}
		else
		{
			System.out.println("no cookies set");
			response.getWriter().println("Enter your credentials and then enter \n");
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.html");
			dispatcher.include(request, response);
		}
		
	}

}
