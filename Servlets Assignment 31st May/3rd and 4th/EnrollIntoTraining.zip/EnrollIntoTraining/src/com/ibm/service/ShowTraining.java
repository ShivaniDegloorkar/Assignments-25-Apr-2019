package com.ibm.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.dao.Dao;


@WebServlet("/showAllTraining")
public class ShowTraining extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");

		
		Cookie[] c = request.getCookies(); int flag = 0; Cookie mycookie = null;
		try
		{
			for(Cookie ck: c)
			{
				if(ck.getName().equals("Username"))
				{
					System.out.println("username found");
					flag = 1;
					mycookie = ck;
					break;
				}
			}
		}catch(NullPointerException e)
		{
			System.out.println("no cookies set");
		}
		
		
		if(flag == 1)
		{
			Dao dao = new Dao();
			PrintWriter pw = response.getWriter();
			int trainingId, availableSeats;
			String trainingCourse;
			pw.println("<html>\r\n" + 
					"<head>\r\n" + 
					"<style>\r\n" + 
					"table, th, td {\r\n" + 
					"  border: 1px solid black;\r\n" + 
					"}\r\n" + 
					"</style>\r\n" + 
					"</head>\r\n" + 
					"<body>\r\n" + 
					"\r\n" + 
					"<table>\r\n" + 
					"  <tr>\r\n" + 
					"    <th>Training ID</th>\r\n" + 
					"    <th>Training Course</th>\r\n" + 
					"    <th>Available Seats</th>\r\n" + 
					"    <th></th>\r\n" + 
					"  </tr>");
			
				int numberOfEntries = dao.getNumberOfCourses();
				System.out.println(numberOfEntries);
				dao.getTrainTable();
				int []trainids = dao.getTrainids();
				String []traincourses = dao.getTrainCourses();
				int []trainseats = dao.getTrainSeats();
				int i = 0;
				while(i < numberOfEntries)
				{
					trainingId	= trainids[i];
					trainingCourse = traincourses[i];
					availableSeats = trainseats[i];
					pw.println("<tr>\r\n" + 
							"    <td>"+ trainingId +"</td>\r\n" + 
							"    <td>"+ trainingCourse +"</td>\r\n" + 
							"    <td>"+ availableSeats +"</td>\r\n" + 
							"    <td><a href=\"enroll?trainid="+trainingId+"&course="+trainingCourse+"\">Enroll</a></td>\r\n" + 
							"  </tr>");
					i++;
					
				}
			
			pw.println("</table>\r\n" + 
					"\r\n "
					+ "<br><br>"
					+ "<form action=\"cookielogout\">\r\n" + 
					"<input type=\"submit\" value=\"Logout\">\r\n" + 
					"</form>" + 
					"</body>\r\n" + 
					"</html>");
			

		}
		else
		{
			System.out.println("no cookies set");
			response.getWriter().println("Enter your credentials and then enter\n");
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.html");
			dispatcher.include(request, response);
		}
			
	}
	
	
}
