package com.ibm.takehome.dao;

import java.util.Map;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.util.CollectionUtil;

public class Dao implements DaoInterface
{
	CollectionUtil collections = new CollectionUtil();

	public Product getProductDetails(String product_code)
	{
		Map<Integer, Product>  products = CollectionUtil.products;
		
		return products.get(Integer.parseInt(product_code));

	}

	
}
