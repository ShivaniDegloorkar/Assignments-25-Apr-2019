package com.ibm.takehome.service;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.exception.UserException;

public interface ServiceInterface 
{
	public boolean validateProductCode(String product_code) throws UserException;
	public Product getProductDetails(String product_code) throws UserException;
	public boolean validateProductQuantity(int product_quantity) throws UserException;
}
