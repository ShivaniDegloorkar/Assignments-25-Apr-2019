package com.ibm.banking.ui;

import java.util.ArrayList;
import java.util.Scanner;
import com.ibm.banking.bean.Customer;
import com.ibm.banking.service.ServiceClass;

public class Main {
	
	static int accountCheck = 0;
	static String passwordCheck = "";
	static Scanner sc;
	static ServiceClass service;
	public static void main(String[] args) 
	{
		int choice;
		int userchoice;
		Customer customer = null;
		sc = new Scanner(System.in);
		service = new ServiceClass();
		
		
HomePage:while(true)
		{
			System.out.println("1.New User?		Create New Account \n"
						     + "2.Existing User:	Log in");
			try 
			{
				userchoice = sc.nextInt();
				sc.nextLine();
				switch(userchoice)
				{
				case 1:
					System.out.println("Welcome!");
					System.out.println("Please enter your name : ");
					String customer_name = sc.nextLine();
					if(!service.validateName(customer_name))
						continue HomePage;
					int account_no = service.generateAccountNo();
EnterPasswordAgain: while(true)
					{	
						System.out.println("Please enter your password : ");
						String password1 = sc.nextLine();
						
						if(service.validatePassword(password1))
						{
							customer = new Customer(account_no,customer_name,1000,password1);
							service.createAccount(customer);
							System.out.println("Account number created for you is: "+account_no);
						}
						else
						{
							continue EnterPasswordAgain;
						}
						continue HomePage;
					}
					
				
				case 2:
					if(loginUser())
					{
						LoginPage:while(true)
						{
							try
							{
							
								System.out.println("Enter choice of operation you want to perform");
								System.out.println("1. View Account balance \n"
												 + "2. Deposit Amount \n"
												 + "3. Withdraw Amount \n"
												 + "4. Transfer Amount \n"
												 + "5. Print transactions \n"
												 + "6. Log Out");
								
								choice = sc.nextInt();
								sc.nextLine();
								switch(choice)
								{
								case 1:
									System.out.println("Your Account Balance is: "+service.viewAccountBalance(accountCheck));
									continue LoginPage;
									
								case 2:
									System.out.println("Please enter amount you want to deposit : ");
									int amountd = sc.nextInt();
									sc.nextLine();
									if(service.DepositBalance(accountCheck,amountd,"main"))
									{
										System.out.println("Amount deposited");
										System.out.println("Your Account Balance is : "+service.viewAccountBalance(accountCheck));
									}
									
									continue LoginPage;
									
								case 3:
									System.out.println("Please enter amount you want to withdraw : ");
									int amountw = sc.nextInt();
									sc.nextLine();
									if(service.withdrawBalance(accountCheck,amountw,"main"))
									{
										System.out.println("Amount withdrawn");
										System.out.println("Your Account Balance is : "+service.viewAccountBalance(accountCheck));
									}
									
									continue LoginPage;
									
								case 4:
									System.out.println("Please enter account number you want to transfer to : ");
									int anotherAccount = sc.nextInt();
									sc.nextLine();
									if(!service.validateAccountNumber(anotherAccount))
									{
										System.out.println("Enter amount you want to transfer");
										int amount = sc.nextInt();
										sc.nextLine();
										if(service.TransferAmount(accountCheck,anotherAccount,amount))
										{
											System.out.println("Amount transfered");
											System.out.println("Your Account Balance is : "+service.viewAccountBalance(accountCheck));
										}
									}
									else
										System.out.println("Sorry! No such account number exixts");
									
									continue LoginPage;
								
								case 5:
									ArrayList<String> list = service.viewTransactionDetails(accountCheck);
									System.out.println("Your transaction history :");
									for(String s: list)
									{
										System.out.println(s);
									}
									continue LoginPage;
									
								case 6:
									accountCheck = 0;
									passwordCheck ="";
									continue HomePage;
									
								default:
									System.out.println("Enter appropriate choice");
								}
							
							
						}
						catch(Exception e)
						{
							System.out.println("Enter input in appropriate format "+e);
							sc.nextLine();
							continue LoginPage;
						}
					}
					}
					else
						continue HomePage;
					
				default:
					System.out.println("Enter appropriate choice");
				}
			}
			catch(Exception e)
			{
				System.out.println("Enter choice in appropriate format"+e);
				sc.nextLine();
			}
		}	
	
	}
	public static boolean loginUser() 
	{
		System.out.println("Kindly Log in");
		System.out.println("Please enter your account number : ");
		accountCheck = sc.nextInt();
		sc.nextLine();
		System.out.println("Please enter your password : ");
		passwordCheck = sc.nextLine();
		
		if(! service.validateLogin(accountCheck,passwordCheck))
		{
			System.out.println("Invalid Login !");
			System.out.println("Please check your credentials");
			return false;
		}
		else
			return true;
			
	}
	
}
